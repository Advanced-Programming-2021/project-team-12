package controllers;

public class BoardController {
}
