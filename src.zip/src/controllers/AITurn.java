package controllers;

public class AITurn {
    public AITurn() {

    }
}
