package controllers.move;

import models.Address;

public class ShowGraveyard {
    public void run(Address address){
        
    }
}
