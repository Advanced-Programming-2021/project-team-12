package controllers.move;

import models.Address;

public class SpecialSummon {
    public void run(Address address){
        
    }
}
