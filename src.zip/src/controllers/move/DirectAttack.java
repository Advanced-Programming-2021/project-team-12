package controllers.move;

import models.Address;

public class DirectAttack {
    public void run(Address address){
        
    }
}
