package controllers.move;

import models.Address;

public class Summon {
    public void run(Address address){
        
    }
}
