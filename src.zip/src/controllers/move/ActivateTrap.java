package controllers.move;

import models.Address;

public class ActivateTrap {
    public void run(Address address){
        
    }
}
