package controllers.move;

import models.Address;

public class ActivateSpell {
    public void run(Address address){
        
    }
}
