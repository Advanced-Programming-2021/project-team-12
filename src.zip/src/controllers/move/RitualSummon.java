package controllers.move;

import models.Address;

public class RitualSummon {
    public void run(Address address){
        
    }
}
