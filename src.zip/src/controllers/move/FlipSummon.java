package controllers.move;

import models.Address;

public class FlipSummon {
    public void run(Address address){
        
    }
}
