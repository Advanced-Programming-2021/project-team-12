package controllers.move;

import models.Address;

public class SetPosition {
    public void run(Address address){
        
    }
}
