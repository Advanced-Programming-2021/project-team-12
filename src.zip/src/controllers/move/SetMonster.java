package controllers.move;

import models.Address;

public class SetMonster {
    public void run(Address address){
        
    }
}
