package controllers.move;

import models.Address;

public class SetTrap {
    public void run(Address address){
        
    }
}
