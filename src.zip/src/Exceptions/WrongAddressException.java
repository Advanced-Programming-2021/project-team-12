package Exceptions;

public class WrongAddressException extends Exception{

}
