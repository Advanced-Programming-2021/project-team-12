package Exceptions;

public class MonsterZoneFull extends Exception{
    public MonsterZoneFull(String message) {
        super(message);
    }
}
