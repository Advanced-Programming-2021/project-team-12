package Exceptions;

public class InvalidCardSelection extends Exception{
    public InvalidCardSelection(String message) {
        super(message);
    }
}
