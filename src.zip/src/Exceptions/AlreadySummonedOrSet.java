package Exceptions;

public class AlreadySummonedOrSet extends Exception{
    public AlreadySummonedOrSet(String message) {
        super(message);
    }
}
