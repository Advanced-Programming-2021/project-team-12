package Exceptions;

public class ValidDeck extends Exception{
    public ValidDeck(String message) {
        super(message);
    }
}
