package Exceptions;

public class Deck {
}
