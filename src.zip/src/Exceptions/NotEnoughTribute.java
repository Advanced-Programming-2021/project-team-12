package Exceptions;

public class NotEnoughTribute extends Exception{
    public NotEnoughTribute(String message) {
        super(message);
    }
}
