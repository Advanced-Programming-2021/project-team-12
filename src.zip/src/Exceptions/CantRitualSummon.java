package Exceptions;

public class CantRitualSummon extends Exception{
    public CantRitualSummon(String message) {
        super(message);
    }
}
