package Exceptions;

public class SideCard extends Exception{
}
