package Exceptions;

public class NotEnoughMoneyException extends Exception{
}
