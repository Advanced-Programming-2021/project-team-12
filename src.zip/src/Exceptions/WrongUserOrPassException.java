package Exceptions;

public class WrongUserOrPassException extends Exception{
}
