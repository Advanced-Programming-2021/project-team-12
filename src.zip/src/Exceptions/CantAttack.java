package Exceptions;

public class CantAttack extends Exception{
    public CantAttack(String message) {
        super(message);
    }
}
