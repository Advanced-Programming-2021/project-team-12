package Exceptions;

public class FullDeck extends Exception{
}
