package Exceptions;

public class UserNameException extends Exception{
}
