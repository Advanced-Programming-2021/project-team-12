package Exceptions;

public class CantDoInThisPhase extends Exception{
    public CantDoInThisPhase(String message) {
        super(message);
    }
}
