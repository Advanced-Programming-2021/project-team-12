package Exceptions;

public class PreperationsAreNotDoneYet extends Exception{
    public PreperationsAreNotDoneYet(String message) {
        super(message);
    }
}
