package Exceptions;

public class CardName extends Exception{
}
