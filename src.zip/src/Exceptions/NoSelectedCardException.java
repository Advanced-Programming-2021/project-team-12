package Exceptions;

public class NoSelectedCardException extends Exception{
    public NoSelectedCardException(String message) {
        super(message);
    }
}
