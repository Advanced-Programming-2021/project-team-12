package Exceptions;

public class BreakException extends Exception{
    public BreakException(String message) {
        super(message);
    }
}
