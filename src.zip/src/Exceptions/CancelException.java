package Exceptions;

public class CancelException extends Exception{
    public CancelException(String message) {
        super(message);
    }
}
