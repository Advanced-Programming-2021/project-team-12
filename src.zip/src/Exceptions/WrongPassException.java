package Exceptions;

public class WrongPassException extends Exception{
}
