package Exceptions;

public class CantSummonThisCard extends Exception{
    public CantSummonThisCard(String message) {
        super(message);
    }
}
