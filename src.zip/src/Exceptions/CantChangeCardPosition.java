package Exceptions;

public class CantChangeCardPosition extends Exception{
    public CantChangeCardPosition(String message) {
        super(message);
    }
}
