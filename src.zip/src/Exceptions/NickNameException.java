package Exceptions;

public class NickNameException extends Exception{
}
