package Exceptions;

public class AcctiveDeck extends Exception{
    public AcctiveDeck(String message) {
        super(message);
    }
}
