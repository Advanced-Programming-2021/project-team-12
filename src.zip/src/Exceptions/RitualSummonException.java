package Exceptions;

public class RitualSummonException extends Exception{
    public RitualSummonException(String message) {
        super(message);
    }
}
