package Exceptions;

public class CantActivateEffect extends Exception{
    public CantActivateEffect(String message) {
        super(message);
    }
}
