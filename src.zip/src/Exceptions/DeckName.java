package Exceptions;

public class DeckName extends Exception{
}
