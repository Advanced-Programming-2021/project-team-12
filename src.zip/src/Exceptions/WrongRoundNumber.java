package Exceptions;

public class WrongRoundNumber extends Exception{
}
