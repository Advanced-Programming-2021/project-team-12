package Exceptions;

public class NoMonsterInThisAddress extends Exception{
    public NoMonsterInThisAddress(String message) {
        super(message);
    }
}
