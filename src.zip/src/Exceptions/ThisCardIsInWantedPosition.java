package Exceptions;

public class ThisCardIsInWantedPosition extends Exception{
    public ThisCardIsInWantedPosition(String message) {
        super(message);
    }
}
