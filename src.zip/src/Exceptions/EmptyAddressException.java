package Exceptions;

public class EmptyAddressException extends Exception{
}
