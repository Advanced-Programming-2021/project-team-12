package Exceptions;

public class ThreeCardDeck extends Exception{
}
