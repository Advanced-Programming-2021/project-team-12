package Exceptions;

public class CardNotExistException extends Exception{
}
