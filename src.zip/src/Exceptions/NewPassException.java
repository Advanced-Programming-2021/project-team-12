package Exceptions;

public class NewPassException extends Exception{
}
