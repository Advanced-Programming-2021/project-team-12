package Exceptions;

public class SpellZoneFull extends Exception{
    public SpellZoneFull(String message) {
        super(message);
    }
}
