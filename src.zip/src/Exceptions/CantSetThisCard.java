package Exceptions;

public class CantSetThisCard extends Exception{
    public CantSetThisCard(String message) {
        super(message);
    }
}
