package Exceptions;

public class MainCard extends Exception{
}
