package models;

public enum PositionOfCardInBoard {
    DO,DH,OO
}
