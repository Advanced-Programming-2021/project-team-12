package models;

public class MonsterMode {

}
