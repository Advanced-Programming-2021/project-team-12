package models;
public enum GamePhase {
    DRAW, 
    STANDBY, 
    MAIN1,
    BATTLE, 
    MAIN2,
    END
}
