package models;

public interface RequiredForEffects {
    
}
