package models;
public enum PlayerTurn {
    FIRSTPLAYER,
    SECONDPLAYER
}
