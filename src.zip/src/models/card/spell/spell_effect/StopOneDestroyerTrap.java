package models.card.spell.spell_effect;

public class StopOneDestroyerTrap implements SpellEffect{
    public void run(){

    }
}
