package models.card.spell.spell_effect;

public class SpellCasterAndFiendIncreaseAttackDefenceFaryDecreaseAttackDefence implements SpellEffect{
    public void run(){

    }
}
