package models.card.spell.spell_effect;

public class IncreaseAttackOrDefenceOfWarrior implements SpellEffect{
    public void run(){

    }
}
