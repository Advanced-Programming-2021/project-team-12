package models.card.spell.spell_effect;

public class SummonOneRitualMonster implements SpellEffect{
    public void run(){

    }
}
