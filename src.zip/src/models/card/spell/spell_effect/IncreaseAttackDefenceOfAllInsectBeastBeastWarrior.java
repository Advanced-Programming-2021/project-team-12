package models.card.spell.spell_effect;

public class IncreaseAttackDefenceOfAllInsectBeastBeastWarrior implements SpellEffect{
    public void run(){

    }
}
