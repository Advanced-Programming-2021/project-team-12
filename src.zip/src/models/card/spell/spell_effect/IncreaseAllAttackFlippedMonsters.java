package models.card.spell.spell_effect;

public class IncreaseAllAttackFlippedMonsters implements SpellEffect{
    @Override
    public void run() {

    }
}
