package models.card.spell.spell_effect;

public class AddFieldSpell implements SpellEffect{
    public void run(){

    }
}
