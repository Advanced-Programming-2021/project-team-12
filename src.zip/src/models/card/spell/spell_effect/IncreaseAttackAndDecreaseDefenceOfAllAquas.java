package models.card.spell.spell_effect;

public class IncreaseAttackAndDecreaseDefenceOfAllAquas implements SpellEffect{
    public void run(){

    }
}
