package models.card.spell.spell_effect;

public class DestroyOneTrapOrSpellCard implements SpellEffect{
    public void run(){

    }
}
