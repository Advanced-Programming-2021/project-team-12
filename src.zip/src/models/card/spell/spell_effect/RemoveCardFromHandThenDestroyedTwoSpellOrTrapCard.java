package models.card.spell.spell_effect;

public class RemoveCardFromHandThenDestroyedTwoSpellOrTrapCard implements SpellEffect{
    public void run(){

    }
}
