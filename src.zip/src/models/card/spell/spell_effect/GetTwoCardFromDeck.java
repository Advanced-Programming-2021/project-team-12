package models.card.spell.spell_effect;

public class GetTwoCardFromDeck implements SpellEffect{
    @Override
    public void run() {

    }
}
