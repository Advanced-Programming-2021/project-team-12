package models.card.spell.spell_effect;

public class ReplacementForDestroyedMonster implements SpellEffect{
    public void run(){

    }
}
