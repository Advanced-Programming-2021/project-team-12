package models.card.spell.spell_effect;

public class FlipCardsAndDontAttackThreeTurns implements SpellEffect{
    @Override
    public void run() {

    }
}
