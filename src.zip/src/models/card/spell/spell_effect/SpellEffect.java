package models.card.spell.spell_effect;

public interface SpellEffect {
    public void run();
}
