package models.card.spell.spell_effect;

public class IncreaseAttackBeastTypes implements SpellEffect{
    public void run(){

    }
}
