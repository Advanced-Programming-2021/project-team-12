package models.card.spell.spell_effect;

public class StopBigMonsterAttackers implements SpellEffect{
    public void run(){

    }
}
