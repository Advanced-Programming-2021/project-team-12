package models.card.spell.spell_effect;

public class ControlRivalMonsterOneRound implements SpellEffect{
    public void run(){

    }
}
