package models.card.spell.spell_effect;

public class IncreaseAttackAndDecreaseDefenceOfSpellcasterOrFiend implements SpellEffect{
    public void run(){

    }
}
