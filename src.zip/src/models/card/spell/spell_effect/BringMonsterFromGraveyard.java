package models.card.spell.spell_effect;

public class BringMonsterFromGraveyard implements SpellEffect{
    public void run(){

    }
}
