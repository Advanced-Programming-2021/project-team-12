package models.card.spell.spell_effect;

public class IncreaseAllAttackMonsters implements SpellEffect{
    @Override
    public void run() {

    }
}
