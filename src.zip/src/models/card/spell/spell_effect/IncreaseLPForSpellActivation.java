package models.card.spell.spell_effect;

public class IncreaseLPForSpellActivation implements SpellEffect{
    public void run(){

    }
}
