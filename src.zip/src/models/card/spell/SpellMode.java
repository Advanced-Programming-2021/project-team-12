package models.card.spell;

public enum SpellMode {
    FIELD,EQUIP, QUICKPLAY,CONTINUOUS,NORMAL,RITUAL
}
