package models.card.monster;

public enum Attribute {
    EARTH,WATER,DARK,FIRE,LIGHT,WIND
}
