package models.card.monster.monster_effect;

import models.card.monster.monster_effect.MonsterEffect;

public class BringLevel7OrMoreFromGraveyard implements MonsterEffect {
    public void run(){

    }
}
