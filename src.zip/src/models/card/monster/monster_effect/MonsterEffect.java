package models.card.monster.monster_effect;

public interface MonsterEffect {
    public void run();
}
