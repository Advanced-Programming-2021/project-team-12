package models.card.trap.trap_effect;

public class ReverseAttack implements TrapEffect{
    public void run(){

    }
}
