package models.card.trap.trap_effect;

public interface TrapEffect {
    public void run();
}
