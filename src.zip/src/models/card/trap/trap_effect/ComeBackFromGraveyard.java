package models.card.trap.trap_effect;

public class ComeBackFromGraveyard implements TrapEffect{
    @Override
    public void run() {

    }
}
