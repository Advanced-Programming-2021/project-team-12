package models.card.trap.trap_effect;

public class DestroyOpponentCard implements TrapEffect{
    public void run(){

    }
}
