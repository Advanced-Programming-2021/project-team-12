package models.card.trap.trap_effect;

public class StopSpecialSummonOrActivation implements TrapEffect{
    @Override
    public void run() {

    }
}
