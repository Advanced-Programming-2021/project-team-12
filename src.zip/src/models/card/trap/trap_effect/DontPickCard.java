package models.card.trap.trap_effect;

public class DontPickCard implements TrapEffect{
    @Override
    public void run() {

    }
}
