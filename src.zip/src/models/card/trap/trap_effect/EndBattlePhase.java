package models.card.trap.trap_effect;

public class EndBattlePhase implements TrapEffect{
    @Override
    public void run() {

    }
}
