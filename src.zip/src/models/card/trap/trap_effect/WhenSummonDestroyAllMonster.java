package models.card.trap.trap_effect;

public class WhenSummonDestroyAllMonster implements TrapEffect{
    @Override
    public void run() {

    }
}
