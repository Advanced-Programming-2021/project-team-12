package models.card.trap.trap_effect;

public class DestroyBigMonsterAttacker implements TrapEffect{
    public void run(){

    }
}
